# Data and Code: Six Control Laws for Multi-Shaker Random Vibration: What Each Does and How It Is Built

Kevin Cross. Hertzforge Journal 1, 2026-007, version 2 (2026-11-17).

The article: https://hertzforge.com/journal/2026-007/v2/
DOI of this version: https://doi.org/10.5281/zenodo.24310228

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_run_sequence, fig2_one_loop, fig3_closed_loop, fig4_shape_directions, fig5_buzz_reference, fig6_min_drive, fig7_band_average. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
