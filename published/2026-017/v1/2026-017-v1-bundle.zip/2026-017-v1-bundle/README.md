# Data and Code: Six Control Laws for Multi-Shaker Sine Testing: The Laws, Their Build in Hertzforge, and How Each Scores on the MIMO Sine Suite

Kevin Cross. Hertzforge Journal 1, 2026-017, version 1 (2026-11-27).

The article: https://hertzforge.com/journal/2026-017/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24595042

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig7_agreement, fig1_readings, fig2_levels, fig3_pairs, fig4_safety, fig5_followed_poles. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
