# Data and Code: A Banded Specification: Convert It to Narrowband, or Control the Band? A Closed-Loop Simulation Study

Kevin Cross. Hertzforge Journal 1, 2026-015, version 1 (2026-11-26).

The article: https://hertzforge.com/journal/2026-015/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24563517

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig_setups, fig_paired, fig_fit, fig_square, fig_stored, fig_update, fig_line, fig_defaults. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
