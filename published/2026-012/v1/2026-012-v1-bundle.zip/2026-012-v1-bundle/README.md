# Data and Code: A Model Finder for Multi-Shaker Random Vibration Tests: Store the Full-Level Model Once, Check It at Low Level, Start Each Test at Full Level. A Simulation Study

Kevin Cross. Hertzforge Journal 1, 2026-012, version 1 (2026-11-25).

The article: https://hertzforge.com/journal/2026-012/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24526655

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig_method, fig_setups, fig_pretest_drive, fig_timing, fig_stored_vs_ladder, fig_laws, fig_seed, fig_suite, fig_reconcile, fig_map, fig_interp, fig_low_span. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
