# Data and Code: The MIMO Shock Suite of the Open Benchmark Set: Pulse Problems on the Random Suite's Structures, Scored by Method 516.8

Kevin Cross. Hertzforge Journal 1, 2026-013, version 2 (2026-11-25).

The article: https://hertzforge.com/journal/2026-013/v2/
DOI of this version: https://doi.org/10.5281/zenodo.24538545

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_article, fig2_targets, fig3_full_level, fig4_effective_duration, fig5_cells, fig6_audit. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
