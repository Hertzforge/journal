# Data and Code: Independent Drive Laws and a Broyden Congruence Law for Multi-Shaker Random Vibration: The Laws, Their Build in Hertzforge, and Their Scores on the Open Benchmark Set

Kevin Cross and Norman Hunter. Hertzforge Journal 1, 2026-011, version 1 (2026-11-20).

The article: https://hertzforge.com/journal/2026-011/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24407970

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig_broyden_example, fig_checks, fig_scores_by_law, fig_level_by_law, fig_stages_by_law, fig_settings, fig_tuning_points, fig_tuning_independent, fig_tuning_broyden_parts, fig_held_back. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
