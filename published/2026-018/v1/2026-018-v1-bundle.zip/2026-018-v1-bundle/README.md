# Data and Code: Multi-Shaker Sine Control: Ideas for a Resonance That Moves With Level That Did Not Work in Simulation, and Why

Kevin Cross. Hertzforge Journal 1, 2026-018, version 1 (2026-11-27).

The article: https://hertzforge.com/journal/2026-018/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24595046

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_mode_shift, fig2_first_screen, fig3_whole_sweep, fig4_leads, fig5_start_error, fig6_stepped, fig7_stepped_trace, fig8_fits. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
