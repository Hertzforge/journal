# Data and Code: The MIMO Sine Suite of the Open Benchmark Set: Swept, Stepped and Dwell Problems on the Random Suite's Structures, Scored by IEC 60068-2-6 and Method 514.8

Kevin Cross. Hertzforge Journal 1, 2026-016, version 1 (2026-11-27).

The article: https://hertzforge.com/journal/2026-016/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24595040

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_article, fig2_tests, fig4_agreement, fig3_before, fig8_audit, fig5_tiers, fig6_levels, fig7_defaults_repeats. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
