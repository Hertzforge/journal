# Data and Code: Multi-Shaker Shock Control: Ideas That Did Not Work in Simulation, and Why

Kevin Cross. Hertzforge Journal 1, 2026-004, version 1 (2026-11-15).

The article: https://hertzforge.com/journal/2026-004/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24254182

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_setup, fig2_test_sequence, fig3_softening_by_level, fig4_networks, fig5_held_out, fig6_unjudged_pulses, fig7_noise_cures. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
