# Data and Code: When the Control Gauges Read Right and the Stress Is Wrong: A Closed-Loop Check of the Proposed Practice for Multi-Shaker Tests

Kevin Cross. Hertzforge Journal 1, 2026-010, version 1 (2026-11-17).

The article: https://hertzforge.com/journal/2026-010/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24311109

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig_setups, fig_paired, fig_what_tracks. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
