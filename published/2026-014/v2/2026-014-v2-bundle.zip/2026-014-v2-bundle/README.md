# Data and Code: Five Control Laws for Multi-Shaker Shock Testing: The Laws, Their Build in Hertzforge, and How Each Scores on the MIMO Shock Suite

Kevin Cross. Hertzforge Journal 1, 2026-014, version 2 (2026-11-25).

The article: https://hertzforge.com/journal/2026-014/v2/
DOI of this version: https://doi.org/10.5281/zenodo.24538548

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_readings, fig2_cells, fig3_safety, fig4_misses, fig5_targets, fig6_port_rust. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
