# Data and Code: An Open Vibration Controller Anyone Can Change: How Hertzforge Is Built, and Why

Kevin Cross and Brandon Zwink. Hertzforge Journal 1, 2026-006, version 1 (2026-11-15).

The article: https://hertzforge.com/journal/2026-006/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24260838

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_architecture, fig2_one_loop, fig3_bench. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
