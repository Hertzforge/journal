# Data and Code: The Open Benchmark Set: Public Test Problems, a Fair Run and a Scorecard for Multi-Shaker Control Laws

Kevin Cross. Hertzforge Journal 1, 2026-008, version 1 (2026-11-17).

The article: https://hertzforge.com/journal/2026-008/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24311105

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig_level_rule, fig_member, fig_article, fig_stage1_band_errors, fig_stage1_element_stress, fig_closed_loop, fig_effects. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
