# Data and Code: What Is a Good Multi-Shaker Test? A Proposed Practice for Judging MIMO Vibration and Shock Tests on Flexible Articles

Kevin Cross and Brandon Zwink. Hertzforge Journal 1, 2026-001, version 1 (2026-11-14).

The article: https://hertzforge.com/journal/2026-001/v1/
DOI of this version: https://doi.org/10.5281/zenodo.24235533

`data/` holds the data behind every figure. `code/` holds the code that draws each one.

## Drawing the Figures Again

These figures are pictures the authors supplied, drawn by their own code in `code/`:
fig1_model_views, fig2_mode_shapes, fig3_example_spectra, fig4_drive_and_single_axis, fig5_exact_fit, fig6_rank_correlation, fig7_floor, fig8_single_axis_decomposition, fig9_line_vs_band, fig10_shock_same_spectrum_spread, fig11_coverage_margin. `code/README.md`, where there is one,
says how to run it.

## License

The data, and the figures drawn from it, are under Creative Commons Attribution 4.0
International (https://creativecommons.org/licenses/by/4.0/): reuse them, with credit to the
authors. The code is under the MIT license. Both are in `LICENSE.txt`.
